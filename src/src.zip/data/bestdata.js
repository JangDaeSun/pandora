let bestdata=[ 

    {
    id: 0,
    title: "오가니컬리 쉐입드 스태킹 링",
    imgUrl: "/img/best-1.png",
    content: "Sterling Silver 925",
    Aprice: 240000,
    price: 218000
    },
    {
    id: 1,
    title: "스파클링 몬스테라 리프 댕글 참",
    imgUrl: "/img/best-2.png",
    content: "큐빅지르코니아, 실버합금 + 14K 골드도금",
    Aprice: 145000,
    price: 118000
    },
    {
    id: 2,
    title: "판도라 모멘츠 하트 클로저 스네이크 체인 브레이슬릿",
    imgUrl: "/img/best-3.png",
    content: "Sterling Silver 925, 실버합금 + 14K 골드도금",
    Aprice: 240000,
    price: 218000
    },
    {
    id: 3,
    title: "트리티드 프레쉬워터 컬처드 펄스 오픈 후프 이어링",
    imgUrl: "/img/best-4.png",
    content: "담수진주, 실버합금 + 14K 골드 도금",
    Aprice: 400000,
    price: 358000
    },
    {
    id: 4,
    title: "트리티드 프레쉬워터 컬처드 펄스 앤 스톤즈 오픈 링",
    imgUrl: "/img/best-5.png",
    content: "담수진주, 합성 크리스탈, 실버합금 + 14K 골드 도금",
    Aprice: 350000,
    price: 318000
    },
    {
    id: 5,
    title: "스파클링 프리핸드 하트 네크리스",
    imgUrl: "/img/best-6.png",
    content: "실버합금 + 14K 로즈골드 도금",
    Aprice: 150000,
    price: 138000
    },


]

export default bestdata;