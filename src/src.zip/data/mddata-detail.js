let Mdetail=[ 

    {
    id: 0,
    imgUrl1: "/img/md-1-detail-1.png",
    imgUrl2: "/img/md-1-detail-2.png",
    },
    {
    id: 1,
    imgUrl1: "/img/md-2-detail-1.png",
    imgUrl2: "/img/md-2-detail-2.png",
    },
    {
    id: 2,
    imgUrl1: "/img/md-3-detail-1.png",
    imgUrl2: "/img/md-3-detail-2.png",
    },
    {
    id: 3,
    imgUrl1: "/img/md-4-detail-1.png",
    imgUrl2: "/img/md-4-detail-2.png",
    },
    {
    id: 4,
    imgUrl1: "/img/md-5-detail-1.png",
    imgUrl2: "/img/md-5-detail-2.png",
    },
    {
    id: 5,
    imgUrl1: "/img/md-6-detail-1.png",
    imgUrl2: "/img/md-6-detail-2.png",
    },
    

]

export default Mdetail;