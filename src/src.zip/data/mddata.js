let mddata=[ 

    {
    id: 0,
    title: "오가니컬리 쉐입드 서클 & 트리티드 프레쉬워터 컬처드 펄 스터드 이어링",
    imgUrl: "/img/md-1.png",
    content: "담수진주, Sterling Silver 925",
    Aprice: 175000,
    price: 158000
    },
    {
    id: 1,
    title: "핑크&옐로우 무라노 글래스 버터플라이 댕글 참",
    imgUrl: "/img/md-2.png",
    content: "큐빅지르코니아, 글라스, 실버합금 + 14K 로즈골드 도금",
    Aprice: 175000,
    price: 158000
    },
    {
    id: 2,
    title: "스파클링 파베 테니스 브레이슬릿",
    imgUrl: "/img/md-3.png",
    content: "Sterling Silver 925",
    Aprice: 199000,
    price: 178000
    },
    {
    id: 3,
    title: "판도라 시그니처 투톤 로고 & 파베 후프 이어링",
    imgUrl: "/img/md-4.png",
    content: "실버합금 + 14K 로즈골드 도금",
    Aprice: 245000,
    price: 218000
    },
    {
    id: 4,
    title: "판도라 미 할베드 에나멜 시그넷 링",
    imgUrl: "/img/md-5.png",
    content: "큐빅지르코니아, 에나멜, 실버합금 + 14K 골드도금",
    Aprice: 225000,
    price: 118000
    },
    {
    id: 5,
    title: "스파클링 블루 허바리움 클러스터 펜던트 네크리스",
    imgUrl: "/img/md-6.png",
    content: "Sterling Silver 925",
    Aprice: 195000,
    price: 178000
    },


]

export default mddata;