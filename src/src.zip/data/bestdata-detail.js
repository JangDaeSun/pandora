let Bdetail=[ 

    {
    id: 0,
    imgUrl1: "/img/best-1-detail-1.png",
    imgUrl2: "/img/best-1-detail-2.png",
    },
    {
    id: 1,
    imgUrl1: "/img/best-2-detail-1.png",
    imgUrl2: "/img/best-2-detail-2.png",
    },
    {
    id: 2,
    imgUrl1: "/img/best-3-detail-1.png",
    imgUrl2: "/img/best-3-detail-2.png",
    },
    {
    id: 3,
    imgUrl1: "/img/best-4-detail-1.png",
    imgUrl2: "/img/best-4-detail-2.png",
    },
    {
    id: 4,
    imgUrl1: "/img/best-5-detail-1.png",
    imgUrl2: "/img/best-5-detail-2.png",
    },
    {
    id: 5,
    imgUrl1: "/img/best-6-detail-1.png",
    imgUrl2: "/img/best-6-detail-2.png",
    },
    

]

export default Bdetail;