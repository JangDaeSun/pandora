let newdata=[ 

    {
    id: 0,
    title: "판도라 미 파베 & 블루 듀얼 링",
    imgUrl: "/img/new-1.png",
    content: "실버합금 + 14K 골드 도금",
    Aprice: 135000,
    price: 118000
    },
    {
    id: 1,
    title: "투톤 엔트와인 밴드 링",
    imgUrl: "/img/new-2.png",
    content: "Sterling Silver 925, 실버합금 + 14K 골드도금",
    Aprice: 230000,
    price: 218000
    },
    {
    id: 2,
    title: "마블 어벤져스 인피니티 스톤 후프이어링",
    imgUrl: "/img/new-3.png",
    content: "실버합금 + 14K 골드 도금",
    Aprice: 270000,
    price: 258000
    },
    {
    id: 3,
    title: "판도라 미 슬림 트리티드 프레시워터 컬처드 펄 네크리스",
    imgUrl: "/img/new-4.png",
    content: "실버합금 + 14K 골드 도금",
    Aprice: 600000,
    price: 558000
    },
    {
    id: 4,
    title: "판도라 미 링크 체인 팔찌",
    imgUrl: "/img/new-5.png",
    content: "메탈합금 + 루테늄도금",
    Aprice: 230000,
    price: 198000
    },
    {
    id: 5,
    title: "투톤 엔트와인 하트 참",
    imgUrl: "/img/new-6.png",
    content: "실버합금 + 14K 골드 도금",
    Aprice: 99000,
    price: 78000
    },


]

export default newdata;